package onlineshopping;

public enum CustomerType {
    REGULAR,
    PREMIUM,
    VIP
}

