from enum import Enum


class CustomerType(Enum):
    REGULAR = "Regular"
    PREMIUM = "Premium"
    VIP = "VIP"
